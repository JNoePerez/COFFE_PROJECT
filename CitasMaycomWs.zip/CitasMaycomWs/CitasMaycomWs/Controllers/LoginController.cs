﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration configuration;
        public LoginController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        // POST: api/Login
        [HttpPost]
        [AllowAnonymous]
        public async Task<RespuestaWS> Login(UsuarioLogin user)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                if (user.Usuario == "username" && user.Password == "password")
                {
                    rsp.Valor=GenerarTokenJWT(user);
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "";
                    rsp.errorMsg2 = "";
                }
                else
                {
                    rsp.Valor =null;
                    rsp.Codigo = -2;
                    rsp.errorMsg1 = "Credenciales inválidas";
                    rsp.errorMsg2 = "";
                }
            }catch(Exception ex)
            {
                rsp.Valor = null;
                rsp.Codigo = -3;
                rsp.errorMsg1 = "Ocurrió un error al intentar realizar la autenticación";
                rsp.errorMsg2 = ex.ToString();
            }
            return rsp;
        }
        private string GenerarTokenJWT(UsuarioLogin usuarioLogin)
        {
            var _symmetricSecurityKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(configuration["JWT:ClaveSecreta"])
                );
            var _signingCredentials = new SigningCredentials(
                    _symmetricSecurityKey, SecurityAlgorithms.HmacSha256
                );
            var _Header = new JwtHeader(_signingCredentials);

            var _Claims = new[] {
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.NameId, usuarioLogin.Usuario.ToString()),
                new Claim("Usuario", usuarioLogin.Usuario),
            };

            var _Payload = new JwtPayload(
                    issuer: configuration["JWT:Issuer"],
                    audience: configuration["JWT:Audience"],
                    claims: _Claims,
                    notBefore: DateTime.UtcNow,
                    // Exipra a la 24 horas.
                    expires: DateTime.UtcNow.AddHours(24)
                );

            var _Token = new JwtSecurityToken(
                    _Header,
                    _Payload
                );

            return new JwtSecurityTokenHandler().WriteToken(_Token);
        }
    }
}