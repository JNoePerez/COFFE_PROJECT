﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaCatalogoController : ControllerBase
    {
        private readonly CitasContext _context;
        public ConsultaCatalogoController(CitasContext context)
        {
            _context = context;
        }
        [HttpGet("{catalogo}")]
        [Authorize]
        public async Task<RespuestaWS> Get(string catalogo)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                var PCATALOGO = new MySqlParameter("PCATALOGO", catalogo);

                var parametros = new object[] {
                   PCATALOGO
                     };
                var data = _context.get_catalogo.FromSqlRaw("call get_catalogo( @PCATALOGO)", parametros).ToList();

                rsp.Codigo = 0;
                rsp.Valor = data;
                rsp.errorMsg1 = string.Empty;
                rsp.errorMsg2 = string.Empty;
            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }
            return rsp;
        }
    }
}
