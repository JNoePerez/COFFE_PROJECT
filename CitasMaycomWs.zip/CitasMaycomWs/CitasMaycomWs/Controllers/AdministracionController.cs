﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AdministracionController : Controller
    {
        private readonly CitasContext _context;
        private General gen = new General();
        public AdministracionController(CitasContext context)
        {
            _context = context;
        }

        [HttpGet("{moduloId}/{fecha}/{cui}/{telefono}/{estatus}")]
        [ActionName("TurnosFiltro")]
        [Authorize]
        public async Task<RespuestaWS> Get(int moduloId,string fecha, string cui, int telefono,int estatus)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {

                var PCUI = new MySqlParameter();
                var PMODULOID = new MySqlParameter("PMODULOID", moduloId);
                var PFECHA = new MySqlParameter();
                var PTELEFONO = new MySqlParameter();
                var PESTATUSID = new MySqlParameter("PESTATUSID", estatus);

                if (fecha == "0")
                {
                     PFECHA = new MySqlParameter("PFECHA", null);
                }
                else
                {
                     PFECHA = new MySqlParameter("PFECHA", fecha);
                }
                if (cui == "0")
                {
                    PCUI = new MySqlParameter("PCUI", null);
                }
                else
                {
                    PCUI = new MySqlParameter("PCUI", cui.Replace("-", "").Trim());
                }
                if (telefono == 0)
                {
                     PTELEFONO = new MySqlParameter("PTELEFONO", null);
                }
                else
                {
                     PTELEFONO = new MySqlParameter("PTELEFONO", telefono.ToString());
                }

                var parametros = new object[] {
                        PMODULOID,
                    PCUI,
                    PFECHA,
                    PTELEFONO,
                    PESTATUSID
                     };

                var data = _context.get_turnos_filtro.FromSqlRaw("call get_turnos_filtro(@PMODULOID, @PCUI, @PFECHA, @PTELEFONO, @PESTATUSID)", parametros).ToList();

                rsp.Codigo = 0;
                rsp.Valor = data.ToList(); 
                rsp.errorMsg1 = string.Empty;
                rsp.errorMsg2 = string.Empty;
            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }
            return rsp;
        }

        [HttpPost]
        [ActionName("Cancelar")]
        [Authorize]
        public RespuestaWS PostCancelar([FromBody]List<Parametro> parametro)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                int idTurno = Convert.ToInt32(parametro[0].Valor.ToString());
                int userID = Convert.ToInt32(parametro[1].Valor.ToString());

                var PTURNOID = new MySqlParameter("PTURNOID", idTurno);
                var PUSUARIOID = new MySqlParameter("PUSUARIOID", userID);

                var parametros = new object[] {
                    PTURNOID,
                    PUSUARIOID
                    };

                var data = _context.upd_anula_turno.FromSqlRaw("call upd_anula_turno_admin( @PTURNOID, @PUSUARIOID)", parametros).ToList();

                if (data.Count > 0)
                {
                    rsp.Codigo = data[0].PCODIGO;
                    rsp.Valor = data[0].PMESSAGE;
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }
                else
                {
                    rsp.Codigo = -1;
                    rsp.Valor = "Error al realizar operacion";
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }

                

            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }

            return rsp;
        }


        [HttpPost]
        [ActionName("Cui")]
        [Authorize]
        public RespuestaWS PostCui([FromBody] List<Parametro> parametro)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                int turnoId = Convert.ToInt32(parametro[0].Valor.ToString());
                string nuevoCui = parametro[1].Valor.ToString();
                int userID = Convert.ToInt32(parametro[2].Valor.ToString());

                string cuiLimpio = nuevoCui.Trim();

                if (cuiLimpio.Length != 13)
                {
                    rsp.Codigo = -5;
                    rsp.errorMsg1 = "La longitud del CUI no es correcta.";
                    rsp.errorMsg2 = "";
                    return rsp;
                }

                var PTURNOID = new MySqlParameter("PTURNOID", turnoId);
                var PCUI_NUEVO = new MySqlParameter("PCUI_NUEVO", cuiLimpio);
                var PUSUARIOID = new MySqlParameter("PUSUARIOID", userID);

                var parametros = new object[] {
                    PTURNOID,
                    PCUI_NUEVO,
                    PUSUARIOID
                    };

                var data = _context.upd_modifica_cui.FromSqlRaw("call upd_actualiza_cui( @PTURNOID, @PCUI_NUEVO, @PUSUARIOID)", parametros).ToList();

                if (data.Count > 0)
                {
                    rsp.Codigo = data[0].PCODIGO;
                    rsp.Valor = data[0].PMESSAGE;
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }
                else
                {
                    rsp.Codigo = -1;
                    rsp.Valor = "Error al realizar operacion";
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }



            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }

            return rsp;
        }

        [HttpPost]
        [ActionName("Correo")]
        [Authorize]
        public RespuestaWS PostCorreo([FromBody] List<Parametro> parametro)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                int turnoId = Convert.ToInt32(parametro[0].Valor.ToString());
                string nuevoCorreo = parametro[1].Valor.ToString();
                int userID = Convert.ToInt32(parametro[2].Valor.ToString());

                var PTURNOID = new MySqlParameter("PTURNOID", turnoId);
                var PCORREO_NUEVO = new MySqlParameter("PCORREO_NUEVO", nuevoCorreo);
                var PUSUARIOID = new MySqlParameter("PUSUARIOID", userID);

                var parametros = new object[] {
                    PTURNOID,
                    PCORREO_NUEVO,
                    PUSUARIOID
                    };

                var data = _context.upd_correo.FromSqlRaw("call upd_actualiza_correo( @PTURNOID, @PCORREO_NUEVO, @PUSUARIOID)", parametros).ToList();

                if (data.Count > 0)
                {
                    rsp.Codigo = data[0].PCODIGO;
                    rsp.Valor = data[0].PMESSAGE;
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }
                else
                {
                    rsp.Codigo = -1;
                    rsp.Valor = "Error al realizar operacion";
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }



            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }

            return rsp;
        }


        [HttpPost]
        [ActionName("Reenvio")]
        [Authorize]
        public RespuestaWS PostReenvio([FromBody] List<Parametro> parametro)
        {
            RespuestaWS rsp = new RespuestaWS();
            bool Envio = false;
            try
            {
                int turnoId = Convert.ToInt32(parametro[0].Valor.ToString());

                List<Turno> turnos = new List<Turno>();
                Turno turnoVals = new Turno();
                var listaTurnos = from turno in _context.turno
                                  where turno.turnoId == turnoId
                                  select new
                                  {
                                      turnoId = turno.turnoId,
                                      moduloId = turno.moduloId,
                                      fecha = turno.fecha,
                                      horarioId = turno.horarioId,
                                      tipo_tramiteid = turno.tipo_tramiteid,
                                      nombre = turno.nombre,
                                      cui = turno.cui,
                                      email = turno.email,
                                      FECHAHORA_INGRESO = turno.FECHAHORA_INGRESO,
                                      estatusId = turno.estatusId,
                                      telefono = 0

                                  };
                listaTurnos.ToList();

                foreach (var item in listaTurnos)
                {
                    turnoVals.turnoId = item.turnoId;
                    turnoVals.moduloId = item.moduloId;
                    turnoVals.fecha = item.fecha;
                    turnoVals.horarioId = item.horarioId;
                    turnoVals.tipo_tramiteid = item.tipo_tramiteid;
                    turnoVals.nombre = item.nombre;
                    turnoVals.cui = item.cui;
                    turnoVals.email = item.email;
                    turnoVals.FECHAHORA_INGRESO = item.FECHAHORA_INGRESO;
                    turnoVals.estatusId = item.estatusId;
                    turnoVals.telefono = item.telefono;

                    turnos.Add(turnoVals);

                }

                if (turnos.Count > 0)
                {
                    //string moduloCorreo = ConsultaModulo(turnos[0].moduloId);
                    string moduloCorreo = ConsultaModuloCorreo(turnos[0].moduloId, turnos[0].fecha);
                    string url = ConsultaUrl(turnos[0].moduloId);
                    string texto = ConsultaTextoModulo(turnos[0].moduloId, turnos[0].fecha);
                    int edad = DateTime.Today.AddTicks(-turnos[0].FECHA_NACIMIENTO.Ticks).Year - 1;
                    bool vEdad = false;
                    if (edad >= 60)
                    {
                        vEdad = true;
                    }

                    
                    if (turnos[0].email.ToUpper() != "SUGERENCIAS@MAYCOM.COM.GT")
                    {
                        Envio = gen.EnviaCorreo(turnoId, turnos[0].tipo_tramiteid, moduloCorreo, turnos[0].fecha, turnos[0].horarioId, turnos[0].nombre, turnos[0].cui, turnos[0].email, "Reenviado", url, texto, vEdad);

                    }
                    else
                    {
                        Envio = true;
                    }

                }
                if (Envio)
                {
                    rsp.Codigo = 0;
                    rsp.Valor ="Envio con exityo";
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }
                else
                {
                    rsp.Codigo = -1;
                    rsp.Valor = "Error al realizar operacion";
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }



            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }

            return rsp;
        }

        public string ConsultaModulo(int ModuloID)
        {
            string Modulo = "";
            List<Modulo> modulos = new List<Modulo>();
            var listaModulo = from cat_modulo in _context.cat_modulo
                              where cat_modulo.estatusId == 2 && cat_modulo.moduloId == ModuloID
                              select cat_modulo;

            modulos = listaModulo.ToList();

            if (modulos.Count > 0)
            {
                Modulo = modulos[0].descripcion;
            }
            else
            {
                Modulo = "";
            }
            return Modulo;
        }
        public string ConsultaModuloCorreo(int ModuloID, DateTime FechaTurno)
        {
            string Modulo = "";
            List<SpCall> respuesta = new List<SpCall>();
            var PMODULOID = new MySqlParameter("PMODULOID", ModuloID);
            var PFECHA = new MySqlParameter("PFECHA", FechaTurno);
            var parametros = new object[] {
                    PMODULOID,
                    PFECHA
                     };
            var data = _context.spGet_modulo_correo.FromSqlRaw("call get_modulo_correo(@PMODULOID, @PFECHA)", parametros).ToList();
            respuesta = data.ToList();
            if (respuesta.Count > 0)
            {
                if (respuesta[0].PCODIGO > 0)
                {
                    Modulo = respuesta[0].PMESSAGE;
                }
            }

            if (Modulo == "")
            {
                Modulo = ConsultaModulo(ModuloID);
            }

            return Modulo;
        }

        public string ConsultaTextoModulo(int ModuloID, DateTime FechaTurno)
        {
            string texto = "";
            List<ModuloTexto> textos = new List<ModuloTexto>();
            var listaTexto = from cat_modulo_texto in _context.cat_modulo_texto
                             where cat_modulo_texto.estatusId == 2 && cat_modulo_texto.moduloId == ModuloID //&& cat_modulo_texto.orderId == number
                             orderby cat_modulo_texto.orderId ascending
                             select cat_modulo_texto;

            textos = listaTexto.ToList();

            foreach (ModuloTexto txt in listaTexto)
            {
                if (txt.fechaInicial != null && txt.fechaFinal != null)
                {
                    if (txt.fechaInicial <= FechaTurno && FechaTurno <= txt.fechaFinal)
                    {
                        texto += txt.descripcion + "<br>";
                    }
                }
                else
                {
                    texto += txt.descripcion + "<br>";
                }
            }

            //if (textos.Count > 0)
            //{
            //    texto = textos[0].descripcion;
            //}
            //else
            //{
            //    texto = "";
            //}
            return texto;
        }

        public string ConsultaUrl(int ModuloID)
        {
            string url = "";
            List<ModuloUrl> urls = new List<ModuloUrl>();
            var listaUrl = from cat_modulo_url in _context.cat_modulo_url
                           where cat_modulo_url.estatusId == 2 && cat_modulo_url.moduloId == ModuloID
                           select cat_modulo_url;

            urls = listaUrl.ToList();

            if (urls.Count > 0)
            {
                url = urls[0].descripcion;
            }
            else
            {
                url = "";
            }
            return url;
        }


    }
}
