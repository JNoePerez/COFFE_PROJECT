﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaCitasController : ControllerBase
    {
        private readonly CitasContext _context;
        public ConsultaCitasController(CitasContext context)
        {
            _context = context;
        }
        [HttpGet("{fechaInicial}/{fechaFinal}")]
        [Authorize]
        public async Task<RespuestaWS> Get(string fechaInicial,string fechaFinal)
        {
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                fechaInicial = fechaInicial.Insert(4,"-").Insert(7,"-");
                fechaFinal = fechaFinal.Insert(4, "-").Insert(7, "-");

                DateTime pFechaInicial = Convert.ToDateTime(fechaInicial);
                DateTime pFechaFinal = Convert.ToDateTime(fechaFinal);
                var PFECHAINI = new MySqlParameter("PFECHAINI", pFechaInicial);
                var PFECHAFIN = new MySqlParameter("PFECHAFIN", pFechaFinal);

                var parametros = new object[] {
                    PFECHAINI,
                    PFECHAFIN
                     };
                var data =_context.get_turnos_fecha.FromSqlRaw("call get_turnos_fecha( @PFECHAINI, @PFECHAFIN)", parametros).ToList();

                rsp.Codigo = 0;
                rsp.Valor = data;
                rsp.errorMsg1 = string.Empty;
                rsp.errorMsg2 = string.Empty;
            }
            catch(Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }
            return rsp;
        }

    }
}