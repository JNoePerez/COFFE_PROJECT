﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaHorarioController : ControllerBase
    {
        private readonly CitasContext _context;
        public ConsultaHorarioController(CitasContext context)
        {
            _context = context;
        }
        private General gen = new General();
        [HttpGet("{moduloId}/{fecha}/{primera}")]
        [Authorize]
        public async Task<RespuestaWS> Get(int moduloId, string fecha, string primera)
        {

            RespuestaWS rsp = new RespuestaWS();

            try
            {
                DateTime fechaa = Convert.ToDateTime(fecha);
                string fechaVal = fechaa.ToString("yyyy-MM-dd");
                int dia = gen.diaFecha(fechaa);
                fechaa = Convert.ToDateTime(fechaVal);
                List<Cat_Horario> listhorario = null;

                int tipoTra = 0;

                if (primera == "true")
                {
                    tipoTra = 1;
                }
                else
                {
                    tipoTra = 2;
                }

                var PMODULOID = new MySqlParameter("PMODULOID", moduloId);
                var PDIAID = new MySqlParameter("PDIAID", dia);
                var PFECHA = new MySqlParameter("PFECHA", fechaa);
                var PTTRAMITE = new MySqlParameter("PTTRAMITE", tipoTra);

                var parametros = new object[] {
                    PMODULOID
                    ,PDIAID
                    ,PFECHA
                    ,PTTRAMITE
                     };


                var data = _context.get_horario_disponible.FromSqlRaw("call get_horario_disponible( @PMODULOID, @PDIAID, @PFECHA, @PTTRAMITE)", parametros).ToList();

                if (data.Count > 0)
                {
                    listhorario = data.ToList();
                    rsp.Codigo = 0;
                    rsp.Valor = listhorario;
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;
                }
                else
                {
                   
                    rsp.Codigo = 0;
                    rsp.Valor = listhorario;
                    rsp.errorMsg1 = "No hay turnos disponibles para la fecha seleccionada.";
                    rsp.errorMsg2 = string.Empty;
                }

              
            }
            catch (Exception ex)
            {
                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }
            return rsp;
        }
    }
}
