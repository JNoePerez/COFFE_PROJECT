﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ARSoft.Tools.Net.Dns;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TurnoController : ControllerBase
    {

        private readonly CitasContext _context;
        private General gen = new General();
        public TurnoController(CitasContext context)
        {
            _context = context;
        }
        [HttpPost]
        [Authorize]
        public RespuestaWS Post(InformacionTurno infoTurno)
        {
            RespuestaWS rsp = new RespuestaWS();
            Turno firstTurno = new Turno();

            try
            {
                Turno singleTurno = new Turno();

                singleTurno.nombre = infoTurno.nombre.ToString().ToUpper();
                singleTurno.email = infoTurno.correo.ToString();
                string cuiError = infoTurno.dpi.ToString();

                try
                {
                    string cuiLimpio = infoTurno.dpi.ToString();
                    cuiLimpio = cuiLimpio.Replace(" ", String.Empty);




                    if (validaCui(cuiLimpio))
                    {
                        singleTurno.cui = cuiLimpio;
                    }
                    else
                    {
                        rsp.Codigo = 0;
                        rsp.errorMsg1 = "El número de DPI ingresado no es valido";
                        firstTurno.nombre = singleTurno.nombre;
                        firstTurno.email = singleTurno.email;
                        firstTurno.cui = cuiError;
                        return rsp;

                    }



                }
                catch (Exception EX)
                {
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "El número de DPI ingresado no es valido";
                    firstTurno.nombre = singleTurno.nombre;
                    firstTurno.email = singleTurno.email;
                    firstTurno.cui = cuiError;
                    return rsp;
                }

                try
                {
                    CultureInfo enUs = new CultureInfo("en-US");
                    singleTurno.FECHA_NACIMIENTO = infoTurno.fechaNac;
                }
                catch (Exception)
                {

                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "La fecha de nacimiento ingresada no es valida";
                    firstTurno.nombre = singleTurno.nombre;
                    firstTurno.email = singleTurno.email;
                    firstTurno.cui = singleTurno.cui;
                    return rsp;

                }


                try
                {
                    if (infoTurno.telefono == null)
                    {
                        infoTurno.telefono = "";
                    }
                    string dato = infoTurno.telefono.ToString();
                    if (dato.Length > 0)
                    {
                        dato = dato.Replace(" ", String.Empty);
                        dato = dato.Replace("-", String.Empty);
                        int telefono = Convert.ToInt32(dato);

                        if (telefono.ToString().Length == 8)
                        {
                            singleTurno.telefono = telefono;
                        }
                        else
                        {
                            rsp.Codigo = 0;
                            rsp.errorMsg1 = "El número de Telefono ingresado no es valido";
                            firstTurno.nombre = singleTurno.nombre;
                            firstTurno.email = singleTurno.email;
                            firstTurno.cui = cuiError;
                            return rsp;


                        }
                    }
                    else
                    {
                        singleTurno.telefono = 0;
                    }

                }
                catch (Exception)
                {
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "El número de teléfono ingresado no es valido";
                    firstTurno.nombre = singleTurno.nombre;
                    firstTurno.email = singleTurno.email;
                    firstTurno.cui = cuiError;
                    return rsp;


                }

                singleTurno.moduloId = infoTurno.moduloId;

                singleTurno.horarioId = infoTurno.horarioId;


                singleTurno.fecha = Convert.ToDateTime(infoTurno.fechaCita.ToString());

                if (infoTurno.tipo_tramiteid == 1)
                {
                    singleTurno.tipo_tramiteid = 1;
                }
                else if (infoTurno.tipo_tramiteid == 2)
                {
                    singleTurno.tipo_tramiteid = 2;
                }
                else if (infoTurno.tipo_tramiteid == 3)
                {
                    singleTurno.tipo_tramiteid = 3;
                }
                else if (infoTurno.tipo_tramiteid == 4)
                {
                    singleTurno.tipo_tramiteid = 4;
                }
                else
                {
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "Debe seleccionar un tipo de tramite a realizar!";
                    return rsp;

                }

                if (!isEmail(singleTurno.email))
                {
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = "La direccion de correo no es valida, favor de verificar";
                    firstTurno.nombre = singleTurno.nombre;
                    firstTurno.email = singleTurno.email;
                    firstTurno.cui = singleTurno.cui;
                    return rsp;

                }

                int dia = gen.diaFecha(singleTurno.fecha);

                try
                {


                    var PMODULOID = new MySqlParameter("PMODULOID", singleTurno.moduloId);
                    var PDIAID = new MySqlParameter("PDIAID", dia);
                    var PHORARIOID = new MySqlParameter("PHORARIOID", singleTurno.horarioId);
                    var PFECHA = new MySqlParameter("PFECHA", singleTurno.fecha);
                    var PTIPOTRAM = new MySqlParameter("PTIPOTRAM", singleTurno.tipo_tramiteid);
                    var PNOMBRE = new MySqlParameter("PNOMBRE", singleTurno.nombre);
                    var PCUI = new MySqlParameter("PCUI", singleTurno.cui);
                    var PEMAIL = new MySqlParameter("PEMAIL", singleTurno.email);
                    var PTELEFONO = new MySqlParameter("PTELEFONO", DBNull.Value);
                    var PFECHANAC = new MySqlParameter("PFECHANAC", singleTurno.FECHA_NACIMIENTO);
                    if (singleTurno.telefono == 0)
                    {
                        PTELEFONO = new MySqlParameter("PTELEFONO", DBNull.Value);
                    }
                    else
                    {
                        PTELEFONO = new MySqlParameter("PTELEFONO", singleTurno.telefono);
                    }
                    var PDIRECCIONIP = new MySqlParameter("PDIRECCIONIP", "0.0.0.0");
                    var PVALADMIN = new MySqlParameter("PVALADMIN", 1);
                    var PUSUARIOCITAID = new MySqlParameter("PUSUARIOCITAID", infoTurno.usuarioId);



                    var parametros = new object[] {
                    PMODULOID
                    ,PDIAID
                    ,PHORARIOID
                    ,PFECHA
                    ,PTIPOTRAM
                    ,PNOMBRE
                    ,PCUI
                    ,PEMAIL
                    ,PTELEFONO
                    ,PFECHANAC
                    ,PDIRECCIONIP
                    ,PVALADMIN
                    ,PUSUARIOCITAID
                    };

                    //if (dia == 7)
                    //{
                    //    rsp.Codigo = 0;
                    //    rsp.errorMsg1 = "No puede crear una cita el dia domingo.";
                    //    return rsp;
                    //}
                    //else
                    //{
                        var data = _context.ins_turnos.FromSqlRaw("call ins_turno( @PMODULOID, @PDIAID, @PHORARIOID, @PFECHA, @PTIPOTRAM, @PNOMBRE, @PCUI, @PEMAIL, @PTELEFONO, @PFECHANAC, @PDIRECCIONIP, @PVALADMIN, @PUSUARIOCITAID)", parametros).ToList();

                        if (data.Count > 0)
                        {
                            if (data[0].PCODIGO == 0)
                            {
                                //string moduloCorreo = ConsultaModulo(singleTurno.moduloId);
                                string moduloCorreo = ConsultaModuloCorreo(singleTurno.moduloId, singleTurno.fecha);
                                string url = ConsultaUrl(singleTurno.moduloId);
                                string texto = ConsultaTextoModulo(singleTurno.moduloId, singleTurno.fecha);
                                int edad = DateTime.Today.AddTicks(-singleTurno.FECHA_NACIMIENTO.Ticks).Year - 1;
                                bool vEdad = false;
                                if (edad >= 60)
                                {
                                    vEdad = true;
                                }

                                bool Envio = false;
                                if (singleTurno.email.ToUpper() != "SUGERENCIAS@MAYCOM.COM.GT")
                                {
                                    Envio = gen.EnviaCorreo(Convert.ToInt32(data[0].PMESSAGE), singleTurno.tipo_tramiteid, moduloCorreo, singleTurno.fecha, singleTurno.horarioId, singleTurno.nombre, singleTurno.cui, singleTurno.email, "Creado", url, texto, vEdad);

                                }
                                else
                                {
                                    Envio = false;
                                }
                                if (Envio)
                                {
                                    rsp.Codigo = 1;
                                    rsp.errorMsg1 = "Turno Creado, se ha enviado un correo con los requisitos."; ;
                                    return rsp;
                                }
                                else
                                {
                                    rsp.Codigo = 1;
                                    rsp.errorMsg1 = "Turno Creado, error al enviar correo";
                                    return rsp;
                                }


                            }
                            else
                            {
                                rsp.Codigo = 0;
                                rsp.errorMsg1 = data[0].PMESSAGE;
                                return rsp;
                            }

                        }
                        else
                        {
                            rsp.Codigo = 0;
                            rsp.errorMsg1 = "Error al realizar operacion";
                            return rsp;
                        }

                    //}
                }
                catch (Exception ex)
                {
                    rsp.Codigo = 0;
                    rsp.errorMsg1 = ex.Message;
                    return rsp;
                }
            }
            catch (Exception e)
            {
                rsp.Codigo = 0;
                rsp.errorMsg1 = e.Message;
                return rsp;
            }
        }

        public string ConsultaTextoModulo(int ModuloID, DateTime FechaTurno)
        {
            string texto = "";
            List<ModuloTexto> textos = new List<ModuloTexto>();
            var listaTexto = from cat_modulo_texto in _context.cat_modulo_texto
                             where cat_modulo_texto.estatusId == 2 && cat_modulo_texto.moduloId == ModuloID //&& cat_modulo_texto.orderId == number
                             orderby cat_modulo_texto.orderId ascending
                             select cat_modulo_texto;

            textos = listaTexto.ToList();

            foreach (ModuloTexto txt in listaTexto)
            {
                if (txt.fechaInicial != null && txt.fechaFinal != null)
                {
                    if (txt.fechaInicial <= FechaTurno && FechaTurno <= txt.fechaFinal)
                    {
                        texto += txt.descripcion + "<br>";
                    }
                }
                else
                {
                    texto += txt.descripcion + "<br>";
                }
            }

            //if (textos.Count > 0)
            //{
            //    texto = textos[0].descripcion;
            //}
            //else
            //{
            //    texto = "";
            //}
            return texto;
        }

        public string ConsultaUrl(int ModuloID)
        {
            string url = "";
            List<ModuloUrl> urls = new List<ModuloUrl>();
            var listaUrl = from cat_modulo_url in _context.cat_modulo_url
                           where cat_modulo_url.estatusId == 2 && cat_modulo_url.moduloId == ModuloID
                           select cat_modulo_url;

            urls = listaUrl.ToList();

            if (urls.Count > 0)
            {
                url = urls[0].descripcion;
            }
            else
            {
                url = "";
            }
            return url;
        }

        public string ConsultaModulo(int ModuloID)
        {
            string Modulo = "";
            List<Modulo> modulos = new List<Modulo>();
            var listaModulo = from cat_modulo in _context.cat_modulo
                              where cat_modulo.estatusId == 2 && cat_modulo.moduloId == ModuloID
                              select cat_modulo;

            modulos = listaModulo.ToList();

            if (modulos.Count > 0)
            {
                Modulo = modulos[0].descripcion;
            }
            else
            {
                Modulo = "";
            }
            return Modulo;
        }
        public string ConsultaModuloCorreo(int ModuloID, DateTime FechaTurno)
        {
            string Modulo = "";
            List<SpCall> respuesta = new List<SpCall>();
            var PMODULOID = new MySqlParameter("PMODULOID", ModuloID);
            var PFECHA = new MySqlParameter("PFECHA", FechaTurno);
            var parametros = new object[] {
                    PMODULOID,
                    PFECHA
                     };
            var data = _context.spGet_modulo_correo.FromSqlRaw("call get_modulo_correo(@PMODULOID, @PFECHA)", parametros).ToList();
            respuesta = data.ToList();
            if (respuesta.Count > 0)
            {
                if (respuesta[0].PCODIGO > 0)
                {
                    Modulo = respuesta[0].PMESSAGE;
                }
            }

            if (Modulo == "")
            {
                Modulo = ConsultaModulo(ModuloID);
            }

            return Modulo;
        }
        public static bool isEmail(string inputEmail)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                  @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                  @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(inputEmail))
            {

                if (DoGetHostEntry(inputEmail))
                {
                    return (true);
                }
                else
                {
                    return (false);
                }


            }

            else
                return (false);
        }


        public static bool DoGetHostEntry(string address)
        {


            try
            {
                string[] host = (address.Split('@'));
                string hostname = host[1];

                var resolver = new DnsStubResolver();
                var records = resolver.Resolve<MxRecord>(hostname, RecordType.Mx);
                if (records.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }


            }
            catch (Exception ex)
            {

                return false;
            }


        }

        public bool validaCui(string cui)
        {
            if (cui.Length != 13)
            {
                return false;
            }
            else
            {
                string digitos = cui.Substring(0, 8);
                string lastdg = cui.Substring(8, 1);
                string codigos = cui.Substring(9, 4);

                try
                {
                    var pCRITERIO = new MySqlParameter("pCRITERIO", "MUNI");
                    var pCODIGO = new MySqlParameter("pCODIGO", codigos);

                    var parametros = new object[] {
                    pCRITERIO
                    ,pCODIGO

                    };

                    var data = _context.get_codigo_depto_maycom.FromSqlRaw("call get_codigo_depto_maycom( @pCRITERIO, @pCODIGO)", parametros).ToList();

                    if (data.Count > 0)
                    {
                        int dgOK = DigitoVerificadorB11(digitos);
                        if (dgOK.ToString() == lastdg)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    else
                    {
                        return false;
                    }

                }
                catch (Exception ex)
                {

                    return false;
                }
            }
        }

        private int DigitoVerificadorB11(string NumRegistroCUI)
        {
            int suma = 0;
            int lastdg = 0;
            int dep;

            int j = 2;
            for (int i = 1; i < 9; i++)
            {
                dep = (j * int.Parse(NumRegistroCUI.Substring((8 - i), 1)));
                suma = suma + dep;
                j = (j + 1);
            }
            int check = suma % 11;
            lastdg = 11 - check;

            if (lastdg == 11) lastdg = 0;

            if (lastdg == 10) lastdg = -1;

            return lastdg;
        }
    }
}
