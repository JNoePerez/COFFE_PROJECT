﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CitasMaycomWs.AppData;
using CitasMaycomWs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;

namespace CitasMaycomWs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TurnoSiguienteController : ControllerBase
    {
        private readonly CitasContext _context;
        public TurnoSiguienteController(CitasContext context)
        {
            _context = context;
        }
        [HttpGet("{moduloId}/{primera}")]
        [Authorize]
        public async Task<RespuestaWS> Get(int moduloId, string primera)
        {
            List<SpTurnoSig> listTurno = null;

            int tipoTra = 0;

            if (primera == "true")
            {
                tipoTra = 1;
            }
            else
            {
                tipoTra = 2;
            }
            RespuestaWS rsp = new RespuestaWS();
            try
            {
                var PMODULOID = new MySqlParameter("PMODULOID", moduloId);
                var PTTRAMITE = new MySqlParameter("PTTRAMITE", tipoTra);

                var parametros = new object[] {
                    PMODULOID,
                    PTTRAMITE
                    };

                var data = _context.get_turno_siguiente.FromSqlRaw("call get_turno_siguiente( @PMODULOID, @PTTRAMITE)", parametros).ToList();

                if (data.Count > 0)
                {

                    listTurno = data.ToList();
                    rsp.Codigo = 0;
                    rsp.Valor = listTurno;
                    rsp.errorMsg1 = string.Empty;
                    rsp.errorMsg2 = string.Empty;

                }
                else
                {
                    rsp.Codigo = -1;
                    rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                    rsp.errorMsg2 = "SP no devolvio datos";
                }
            }
            catch (Exception ex)
            {

                rsp.Codigo = -1;
                rsp.errorMsg1 = "Ocurrió un error al intentar ejecutar el procedimiento almacenado";
                rsp.errorMsg2 = ex.ToString();
            }

            return rsp;
        }
    }
}
