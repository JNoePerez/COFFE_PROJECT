﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class Municipio
    {
        [Key]
        public int municId { get; set; }
        public string DESCRIPCION { get; set; }
    }
}
