﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class RespuestaWS
    {
        public int Codigo { get; set; }
        public string errorMsg1 { get; set; }
        public string errorMsg2 { get; set; }
        public object Valor { get; set; }
    }
}
