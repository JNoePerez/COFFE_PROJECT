﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class InformacionTurno
    {
        public string nombre { get; set; }
        public string dpi { get; set; }
        public string correo { get; set; }
        public DateTime fechaNac { get; set; }
        public string telefono { get; set; }
        public int moduloId { get; set; }
        public DateTime fechaCita { get; set; }
        public int horarioId { get; set; }
        public int tipo_tramiteid { get; set; }
        public int usuarioId { get; set; }
    }
}
