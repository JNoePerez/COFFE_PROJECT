﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class ModuloTexto
    {
        [Key]
        public int textoId { get; set; }
        public int moduloId { get; set; }
        public int orderId { get; set; }
        public string descripcion { get; set; }
        public int estatusId { get; set; }
        public DateTime? fechaInicial { get; set; }
        public DateTime? fechaFinal { get; set; }
    }
}
