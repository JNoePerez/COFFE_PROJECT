﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class Turno
    {
        public int turnoId { get; set; }
        public int moduloId { get; set; }
        public DateTime fecha { get; set; }
        public int horarioId { get; set; }
        public int tipo_tramiteid { get; set; }
        public string nombre { get; set; }
        public string cui { get; set; }
        public string email { get; set; }
        public DateTime FECHAHORA_INGRESO { get; set; }
        public int estatusId { get; set; }
        public int telefono { get; set; }
        public DateTime FECHA_NACIMIENTO { get; set; }


    }
}
