﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class SpCall
    {
        [Key]
        public int PCODIGO { get; set; }
        public string PMESSAGE { get; set; }
    }
}
