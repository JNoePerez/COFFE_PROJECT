﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Text;

namespace CitasMaycomWs.Models
{
    public class General
    {
        public int diaFecha(DateTime fecha)
        {
            int dia = -1;

            string diaSemana = fecha.ToString("dddd");


            switch (diaSemana.ToUpper())
            {
                case "LUNES":
                    dia = 1;
                    break;
                case "MARTES":
                    dia = 2;
                    break;
                case "MIÉRCOLES":
                    dia = 3;
                    break;
                case "JUEVES":
                    dia = 4;
                    break;
                case "VIERNES":
                    dia = 5;
                    break;
                case "SÁBADO":
                    dia = 6;
                    break;
                case "DOMINGO":
                    dia = 7;
                    break;
                case "MONDAY":
                    dia = 1;
                    break;
                case "TUESDAY":
                    dia = 2;
                    break;
                case "WEDNESDAY":
                    dia = 3;
                    break;
                case "THURSDAY":
                    dia = 4;
                    break;
                case "FRIDAY":
                    dia = 5;
                    break;
                case "SATURDAY":
                    dia = 6;
                    break;
                case "SUNDAY":
                    dia = 7;
                    break;
                default:
                    dia = 0;
                    break;
            }

            return dia;
        }

        public string ConsultaTipoTramite(int TipoTramiteID)
        {
            string Tramite = "";
            switch (TipoTramiteID)
            {
                case 1:
                    Tramite = "PRIMERA LICENCIA";
                    break;
                case 2:
                    Tramite = "RENOVACI&Oacute;N DE LICENCIA";
                    break;
                case 3:
                    Tramite = "REPOSICI&Oacute;N DE LICENCIA";
                    break;
                case 4:
                    Tramite = "TRANSFERENCIA DE LICENCIA";
                    break;
            }
            return Tramite;
        }


        public string ConsultaTipoTramite2(int TipoTramiteID)
        {
            string Tramite = "";
            switch (TipoTramiteID)
            {
                case 1:
                    Tramite = "PRIMERA LICENCIA";
                    break;
                case 2:
                    Tramite = "RENOVACIÓN DE LICENCIA";
                    break;
                case 3:
                    Tramite = "REPOSICIÓN DE LICENCIA";
                    break;
                case 4:
                    Tramite = "TRANSFERENCIA DE LICENCIA";
                    break;
            }
            return Tramite;
        }

        private string Requisitos(int TipoTramiteID)
        {
            string Requisitos = "";
            switch (TipoTramiteID)
            {
                case 1:
                    Requisitos += "<b>PARA MAYOR DE EDAD</b><ul>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado.</li>";
                    //Requisitos += "<li>Original y fotocopia de Boleto de Ornato del año en curso.</li>";
                    Requisitos += "<li><b>Primera licencia tipo \"E\":</b>Presentar fotocopia de Patente de Comercio y carta extendida por la empresa en donde trabaja la persona interesada</li></ul>";
                    Requisitos += "<b>PARA MENORES DE EDAD (Tener 16 años cumplidos)</b><ul><li>Certificaci&oacute;n original de nacimiento extendida por RENAP, con un m&aacute;ximo de 6 meses de emisi&oacute;n.</li>";
                    Requisitos += "<li>Carta de responsabilidad del padre o tutor legal autenticada por abogado.</li>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado del padre o tutor legal.</li>";
                    Requisitos += "<li>Comprobante de pago por un año (Q.100.00)</li></ul>";
                    Requisitos += "<b>Adicional para todos los casos, debe presentar:</b>";
                    Requisitos += "<ul><li>Estar solvente de multas</li>";
                    Requisitos += "<li>Certificado de aprobaci&oacute;n de examen te&oacute;rico-pr&aacute;ctico de manejo, extendido por Escuela de Automovilismo autorizada por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original emitida por la Escuela de Automovilismo autorizada.</li>";
                    Requisitos += "<li>Examen de la vista emitido por una Cl&iacute;nica &Oacute;ptica u Oftalm&oacute;logo profesional colegiado activo, que cumpla con los requisitos establecidos por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original del examen de la vista y fotocopia.</li>";
                    Requisitos += "<li>Recibo de pago por el monto de los años de vigencia que desee en su licencia, realizarlo &uacute;nicamente en agencias Banrural ubicadas en el interior de Maycom.</li>";
                    Requisitos += "</ul>";
                    break;
                case 2://renovacion
                    Requisitos += "<b>PARA MAYOR DE EDAD</b><ul>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado.</li>";
                    //Requisitos += "<li>Original y fotocopia de Boleto de Ornato del año en curso.</li>";
                    Requisitos += "</ul>";
                    Requisitos += "<b>PARA MENORES DE EDAD (Tener 16 años cumplidos)</b><ul><li>Certificaci&oacute;n original de nacimiento extendida por RENAP, con un m&aacute;ximo de 6 meses de emisi&oacute;n.</li>";
                    Requisitos += "<li>Carta de responsabilidad del padre o tutor legal autenticada por abogado.</li>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado del padre o tutor legal.</li>";
                    Requisitos += "<li>Comprobante de pago por un año (Q.100.00)</li></ul>";
                    Requisitos += "<b>Adicional para ambos casos, debe presentar:</b><ul>";
                    Requisitos += "<li>Estar solvente de multas</li>";
                    Requisitos += "<li>Presentar licencia de conducir a renovar.</li>";
                    Requisitos += "<li>Examen de la vista emitido por una Cl&iacute;nica &Oacute;ptica u Oftalm&oacute;logo profesional colegiado activo, que cumpla con los requisitos establecidos por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original del examen de la vista y fotocopia.</li>";
                    Requisitos += "<li>Recibo de pago por el monto de los años de vigencia que desee en su licencia, realizarlo &uacute;nicamente en agencias Banrural ubicadas en el interior de Maycom.</li>";
                    Requisitos += "</ul>";
                    break;
                case 3://reposicion (perdida o robo)
                    Requisitos += "<b>PARA MAYOR DE EDAD</b><ul>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado.</li>";
                    //Requisitos += "<li>Original y fotocopia de Boleto de Ornato del año en curso.</li>";
                    Requisitos += "</ul>";
                    Requisitos += "<b>PARA MENORES DE EDAD</b><ul><li>Certificaci&oacute;n original de nacimiento extendida por RENAP, con un m&aacute;ximo de 6 meses de emisi&oacute;n.</li>";
                    Requisitos += "<li>Carta de responsabilidad del padre o tutor legal autenticada por abogado.</li>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado del padre o tutor legal.</li>";
                    Requisitos += "</ul>";
                    Requisitos += "<b>Adicional para ambos casos, debe presentar:</b><ul>";
                    Requisitos += "<li>Denuncia ante autoridad competente por robo o Declaraci&oacute;n Jurada ante un abogado por perdida.</li>";
                    Requisitos += "<li>Estar solvente de multas</li>";
                    Requisitos += "<li>Examen de la vista emitido por una Cl&iacute;nica &Oacute;ptica u Oftalm&oacute;logo profesional colegiado activo, que cumpla con los requisitos establecidos por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original del examen de la vista y fotocopia.</li>";
                    Requisitos += "<li>Recibo de pago por reposici&oacute;n de su licencia (Q.100.00), realizarlo &uacute;nicamente en agencias Banrural ubicadas en el interior de Maycom.</li>";
                    Requisitos += "</ul>";
                    break;
                case 4://transferencia de licencia
                    Requisitos += "<b>Requisitos indispensables para transferir a licencia Tipo “A”</b>";
                    Requisitos += "<ul><li>Un m&iacute;nimo de 3 años  en poseer licencia vigente tipo B o tipo C.</li>";
                    Requisitos += "<li>Tener como m&iacute;nimo 25 años cumplidos.</li></ul>";
                    Requisitos += "<b>Requisitos indispensables para transferir a licencia Tipo  “B”</b>";
                    Requisitos += "<ul><li>Un m&iacute;nimo de 2 años en poseer licencia vigente tipo C.</li>";
                    Requisitos += "<li>Tener como m&iacute;nimo 23 años cumplidos.</li></ul>";
                    Requisitos += "<b>Adicional para ambos casos, debe presentar:</b>";
                    Requisitos += "<ul><li>Certificado de aprobaci&oacute;n de examen te&oacute;rico-pr&aacute;ctico de manejo, extendido por Escuela de Automovilismo autorizada por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original emitida por la Escuela de Automovilismo autorizada.</li>";
                    Requisitos += "<li>Copia legalizada y legible, autorizada por un notario p&uacute;blico del T&iacute;tulo, Diploma o Certificado que acredite el nivel acad&eacute;mico, para realizar el tr&aacute;mite de transferencia como lo establece el Decreto 15-2014 (Transferencias de tipo de licencia de C-B, C-A, B-A).</li>";
                    Requisitos += "<li>Examen de la vista emitido por una Cl&iacute;nica &Oacute;ptica u Oftalm&oacute;logo profesional colegiado activo, que cumpla con los requisitos establecidos por el Departamento de Tr&aacute;nsito de la Polic&iacute;a Nacional Civil.</li>";
                    Requisitos += "<li>Factura original del examen de la vista y fotocopia.</li>";
                    Requisitos += "<li>Recibo de pago por transferencia de su licencia (Q.100.00), realizarlo &uacute;nicamente en agencias Banrural ubicadas en el interior de Maycom.</li>";
                    //Requisitos += "<li>Original y fotocopia de Boleto de Ornato del año en curso</li>";
                    Requisitos += "<li>Estar solvente de multas.</li>";
                    Requisitos += "<li>Original y fotocopia del documento de identificaci&oacute;n (DPI) en buen estado.</li>";
                    Requisitos += "<li>Licencia de conducir vigente.</li></ul>";
                    break;
            }
            return Requisitos;
        }

        public string ConsultaHora(int HoraID)
        {
            string Hora = "";
            switch (HoraID)
            {
                case 1:
                    Hora = "07:00 AM";
                    break;
                case 2:
                    Hora = "07:30 AM";
                    break;
                case 3:
                    Hora = "08:00 AM";
                    break;
                case 4:
                    Hora = "08:30 AM";
                    break;
                case 5:
                    Hora = "09:00 AM";
                    break;
                case 6:
                    Hora = "09:30 AM";
                    break;
                case 7:
                    Hora = "10:00 AM";
                    break;
                case 8:
                    Hora = "10:30 AM";
                    break;
                case 9:
                    Hora = "11:00 AM";
                    break;
                case 10:
                    Hora = "11:30 AM";
                    break;
                case 11:
                    Hora = "12:00 PM";
                    break;
                case 12:
                    Hora = "12:30 PM";
                    break;
                case 13:
                    Hora = "01:00 PM";
                    break;
                case 14:
                    Hora = "01:30 PM";
                    break;
                case 15:
                    Hora = "02:00 PM";
                    break;
                case 16:
                    Hora = "02:30 PM";
                    break;
                case 17:
                    Hora = "03:00 PM";
                    break;
                case 18:
                    Hora = "03:30 PM";
                    break;
                case 19:
                    Hora = "04:00 PM";
                    break;
                case 20:
                    Hora = "04:30 PM";
                    break;
                case 21:
                    Hora = "05:00 PM";
                    break;
                case 22:
                    Hora = "05:30 PM";
                    break;
                case 23:
                    Hora = "06:00 PM";
                    break;
                case 24:
                    Hora = "06:30 PM";
                    break;
                case 25:
                    Hora = "07:00 PM";
                    break;
                default:
                    Hora = "";
                    break;
            }
            return Hora;
        }

        private string Mes(int MesID)
        {
            string mes = "";
            switch (MesID)
            {
                case 1:
                    mes = "Enero";
                    break;
                case 2:
                    mes = "Febrero";
                    break;
                case 3:
                    mes = "Marzo";
                    break;
                case 4:
                    mes = "Abril";
                    break;
                case 5:
                    mes = "Mayo";
                    break;
                case 6:
                    mes = "Junio";
                    break;
                case 7:
                    mes = "Julio";
                    break;
                case 8:
                    mes = "Agosto";
                    break;
                case 9:
                    mes = "Septiembre";
                    break;
                case 10:
                    mes = "Octubre";
                    break;
                case 11:
                    mes = "Noviembre";
                    break;
                case 12:
                    mes = "Diciembre";
                    break;
            }

            return mes;
        }

        public bool EnviaCorreo(int TurnoID, int TipoTramiteID, string modulo, DateTime Fecha, int HorarioID, string Nombre, string CUI, string CorreoUsuario, string operacion, string url, string texto1, bool edad)
        {
            try
            {
                //cargar de parametros
                string Tramite = ConsultaTipoTramite(TipoTramiteID);
                //string modulo = ConsultaModulo(ModuloId);
                string mes = Mes(Fecha.Month);
                string Hora = ConsultaHora(HorarioID);
                string digitosIni = CUI.Substring(0, 4);
                string digitosMid = CUI.Substring(4, 5);
                string digitosLast = CUI.Substring(9, 4);
                string cuiNew = digitosIni + "-" + digitosMid + "-" + digitosLast;
                //instanciar cliente
                SmtpClient cliente = new SmtpClient();

                //inicializar parametros de cliente
                cliente.Host = "smtp.office365.com";
                cliente.Port = 587;
                cliente.EnableSsl = true;
                cliente.DeliveryMethod = SmtpDeliveryMethod.Network;
                cliente.UseDefaultCredentials = false;

                //******************sustituir por credenciales autorizadas****************************
                cliente.Credentials = new NetworkCredential("citas@maycom.com.gt", "M@yc0mC1t4s2020");
                //******************sustituir por credenciales autorizadas****************************

                //instanciar mensaje de correo
                MailMessage Correo = new MailMessage();

                //asignar parametros de mensaje de correo
                Correo.From = new MailAddress("citas@maycom.com.gt", "MAYCOM");
                Correo.To.Add(new MailAddress(CorreoUsuario, Nombre));
                Correo.Subject = "MAYCOM - Confirmación de cita";
                string bodyMayor = "";
                if (edad)
                {
                    bodyMayor = "</li><li>Favor informar al ingreso del centro su edad, para poder atenderlo de manera preferencial.";
                }
                else
                {
                    bodyMayor = "";
                }

                //cuerpo del correo
                string body = "";
                body += "<!DOCTYPE html>";
                body += "<html>";
                body += "<head>";
                body += "<meta charset='utf-8'>";
                body += "<meta http-equiv='X-UA-Compatible' content='IE=edge'>";
                body += "<title>MAYCOM - Confirmaci&oacute;n de cita</title>";
                body += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
                body += "<style type=\"text/css\">";
                body += "@media screen {@font-face {font-family: 'Source Sans Pro';font-style: normal;font-weight: 400;";
                body += "src: local('Source Sans Pro Regular'), local('SourceSansPro-Regular'), url(https://fonts.gstatic.com/s/sourcesanspro/v10/ODelI1aHBYDBqgeIAH2zlBM0YzuT7MdOe03otPbuUS0.woff) format('woff');}";
                body += "@font-face {font-family: 'Source Sans Pro';font-style: normal;font-weight: 700;";
                body += "src: local('Source Sans Pro Bold'), local('SourceSansPro-Bold'), url(https://fonts.gstatic.com/s/sourcesanspro/v10/toadOcfmlt9b38dHJxOBGFkQc6VGVFSmCnC_l7QZG60.woff) format('woff');}}";
                body += "body,table,td,a {-ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; }table,td {mso-table-rspace: 0pt;mso-table-lspace: 0pt;}img {-ms-interpolation-mode: bicubic;}";
                body += "a[x-apple-data-detectors] {font-family: inherit !important;font-size: inherit !important;font-weight: inherit !important;line-height: inherit !important;color: inherit !important;text-decoration: none !important;}";
                body += "div[style*=\"margin: 16px 0; \"] {margin: 0 !important;}body {width: 100% !important;height: 100% !important;padding: 0 !important;margin: 0 !important;}";
                body += "table {border-collapse: collapse !important;}a {color: #1a82e2;}img {height: auto;line-height: 100%;text-decoration: none;border: 0; outline: none;}";
                body += "</style>";
                body += "</head>";
                body += "<body style=\"background - color: #0974df;\">";
                body += "<div class=\"preheader\" style=\"display: none; max - width: 0; max - height: 0; overflow: hidden; font - size: 1px; line - height: 1px; color: #fff; opacity: 0;\">";
                body += "MAYCOM - Correo de confirmaci&oacute;n de cita.";
                body += "</div>";
                body += "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td align=\"center\" bgcolor=\"#e9ecef\">";
                body += "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width: 600px; \"><tr><td align=\"center\" valign=\"top\" style=\"padding: 36px 24px; \">";
                body += "<a href=\"http://maycom.com.gt\" target=\"_blank\" style=\"display: inline-block;\">";
                body += "<img src=\"https://citas.maycom.com.gt/app-assets/img/nuevoLogoMaycom.jpg\" alt=\"Logo\" border=\"0\" width=\"100\" style=\"display: block; width: 100px; max-width: 100px; min-width: 100px;\"></a></td></tr>";
                body += "</table></td></tr>";
                body += "<tr><td align=\"center\" bgcolor=\"#e9ecef\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width: 600px;\"><tr>";
                body += "<td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 36px 24px 0; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; border-top: 3px solid #d4dadf;\">";
                body += "<h1 style=\"margin: 0; font-size: 32px; font-weight: 700; letter-spacing: -1px; line-height: 48px; color:#1a5dac; text-align: center;\">";
                body += "Confirmaci&oacute;n de cita para <br>" + Tramite + "</h1>"; //tramite
                body += "</td></tr></table></td></tr>";
                body += "<tr><td align=\"center\" bgcolor=\"#e9ecef\">";
                body += "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width: 600px;\">";
                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;\">";
                body += "<p style=\"margin: 0; \">";
                body += "Su cita ha sido programada correctamente con la siguiente informaci&oacute;n:";
                body += "</p></td></tr>";
                body += "<tr><td><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">";
                body += "<tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">Turno:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + operacion + "</b></td></tr>"; //Turno
                body += "<tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">Nombre:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + Nombre.ToUpper() + "</b></td></tr>"; //Nombre
                body += "<tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">CUI:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + cuiNew + "</b></td></tr>"; //CUI
                body += "<tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">Agencia:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + modulo + "</b></td></tr>"; //modulo
                body += "<tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">Fecha:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + Fecha.Day.ToString() + " de " + mes + " de " + Fecha.Year.ToString() + "</b>"; //fecha
                body += "</td></tr><tr><td align=\"right\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">Hora:</td><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px;\">";
                body += "<b>" + Hora + "</b>";
                body += "</td></tr>";
                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 12px; color: #fe0808;\" colspan=\"2\"><b>" + texto1 + "</b>";
                body += "</td></tr>";
                body += "<tr><td align=\"left\" bgcolor=\"#1a5dac\" style=\"padding: 12px; color: #ffffff;\" colspan=\"2\"><b>NOTA IMPORTANTE:</b>";
                body += "<ol><li>Presentar esta confirmaci&oacute;n impresa/digital para ingresar</li>";
                body += "<li>Presentarse al Centro de Emisi&oacute;n, 20 minutos antes de la cita con sus documentos necesarios para el tr&aacute;mite.</li>";
                body += "<li>En caso de no cumplir los requisitos, no llegar o llegar despues de su hora programada para la cita, no podr&aacute; ingresar y deber&aacute; realizar una nueva cita.</li>";
                body += "<li>La cita puede ser cancelada derivado de las disposiciones gubernamentales vigentes o contención de casos positivos COVID-19.</li>";
                body += bodyMayor;
                body += "</ol></td></tr>";
                body += "<tr><td align=\"left\" bgcolor =\"#ffffff\" style =\"padding: 12px; \" colspan =\"2\" > ";
                body += "<a  href=\"" + url + "\" target =\"_blank\" > Click aqu&iacute; para m&aacute;s informaci&oacute;n.</a>";
                body += "</td></tr></table></td></tr>";
                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;\">";
                body += "<p style=\"margin: 0; \">";
                body += "Recuerde que debe cumplir con los siguientes requisitos el d&iacute;a de su cita:";
                body += "</p>";
                body += Requisitos(TipoTramiteID);//requisitos
                body += "</td></tr>";
                
                /*
                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;\"><p style=\"margin: 0;\">";
                body += "Si desea realizar cambios en su cita o desea cancelarla, puede realizarlo en los siguientes enlaces:";
                body += "</p></td></tr>";
                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td align=\"center\" bgcolor=\"#ffffff\" style=\"padding: 12px;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
                body += "<tr><td align=\"center\" bgcolor=\"#1a82e2\" style=\"border-radius: 6px;\">";
                body += "<a href=\"";
                body += "https://citas.maycom.com.gt/Recalendarizar/Index/" + CodificiarURL(TurnoID);
                //body += "https://localhost:44379/Recalendarizar/Index/" + CodificiarURL(TurnoID);
                body += "\" style=\"display: inline-block; padding: 16px 36px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; border-radius: 6px;\">Reprogramar Cita</a></td>";
                body += "<td align=\"center\" bgcolor=\"#ec1d1d\" style=\"border-radius: 6px;\">";
                body += "<a href=\"";
                body += "https://citas.maycom.com.gt/Cancelar/Index/" + CodificiarURL(TurnoID);
                //body += "https://localhost:44379/Cancelar/Index/" + CodificiarURL(TurnoID);
                body += "\" style=\"display: inline-block; padding: 16px 36px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; border-radius: 6px;\">Cancelar Cita</a></td>";
                body += "</tr></table></td></tr></table></td></tr><tr>";
                body += "<td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;\">";
                body += "</td></tr>";
                */


                body += "<tr><td align=\"left\" bgcolor=\"#ffffff\" style=\"padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px; border-bottom: 3px solid #d4dadf\">";
                body += "<p style=\"margin: 0;\">Saludos cordiales,<br> MAYCOM - Centro de Emisi&oacute;n de licencias.</p></td></tr></table></td>";
                body += "</tr><tr><td align=\"center\" bgcolor=\"#e9ecef\" style=\"padding: 24px;\">";
                body += "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"max-width: 600px;\">";
                body += "<tr><td align=\"center\" bgcolor=\"#e9ecef\" style=\"padding: 12px 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; color: #666;\">";
                body += "<p style=\"margin: 0;\">Este es un correo generado de forma autom&aacute;tica, favor de no responder.</p>";
                body += "<p style=\"margin: 0; \">Usted recibi&oacute; este email porque realiz&oacute; un tr&aacute;mite en l&iacute;nea en MAYCOM, si usted no realiz&oacute; ninguna gesti&oacute;n puede eliminarlo.</p></td></tr></table>";
                body += "</body></html>";
                body += "";

                //configuracion del mensaje y envio
                Correo.Body = body;
                Correo.IsBodyHtml = true;
                Correo.Priority = MailPriority.Normal;
                cliente.Send(Correo);
                body = "";
                return true;
            }
            catch
            {
                return false;
            }
        }

        private string CodificiarURL(int TurnoID)
        {

            string URLResultado = Encriptar(TurnoID.ToString());
            return URLResultado;
        }
        public string DecodificarURL(string URLCodificada)
        {
            return DesEncriptar(URLCodificada);
        }

        public string Encriptar(string QueryString)
        {
            Cifrado objCifrado = new Cifrado();
            return objCifrado.EncryptText(QueryString, "Maycom2020");
        }
        public string DesEncriptar(string QueryString)
        {
            DesEncryptCs objCifrado = new DesEncryptCs();
            return objCifrado.DecryptText(QueryString, "Maycom2020");
        }


    }
}
