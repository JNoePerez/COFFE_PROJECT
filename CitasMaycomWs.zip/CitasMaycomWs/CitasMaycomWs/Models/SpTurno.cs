﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class SpTurno
    {
        [Key]
        public int id { get; set; }
        public int moduloid { get; set; }
        public string fechaturno { get; set; }
        public int estatusid { get; set; }
        public int horarioid { get; set; }
        public string horario { get; set; }
        public int total { get; set; }

    }
}

