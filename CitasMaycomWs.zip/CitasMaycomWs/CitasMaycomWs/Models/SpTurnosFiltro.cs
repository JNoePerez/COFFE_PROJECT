﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.Models
{
    public class SpTurnosFiltro
    {
        [Key]
        public int turnoId { get; set; }
        public int moduloId { get; set; }
        public string modulo { get; set; }
        public DateTime fecha { get; set; }
        public int horarioId { get; set; }
        public int tipo_tramiteid { get; set; }
        public string nombre { get; set; }
        public string cui { get; set; }
        public string email { get; set; }
        public DateTime FECHAHORA_INGRESO { get; set; }
        public int estatusId { get; set; }
        public string estado { get; set; }
        public int telefono { get; set; }
    }
}
