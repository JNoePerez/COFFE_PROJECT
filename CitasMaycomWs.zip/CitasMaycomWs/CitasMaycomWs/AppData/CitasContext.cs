﻿using CitasMaycomWs.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CitasMaycomWs.AppData
{
    public class CitasContext: DbContext
    {
        public virtual DbSet<SpTurno> get_turnos_fecha { get; set; }
        public virtual DbSet<SpCatalogo> get_catalogo { get; set; }
        public virtual DbSet<SpTurnoSig> get_turno_siguiente { get; set; }
        public virtual DbSet<Cat_Horario> get_horario_disponible { get; set; }
        public DbSet<Modulo> cat_modulo { get; set; }
        public DbSet<ModuloUrl> cat_modulo_url { get; set; }
        public DbSet<ModuloTexto> cat_modulo_texto { get; set; }
        public virtual DbSet<Municipio> get_codigo_depto_maycom { get; set; }
        public virtual DbSet<SpCall> ins_turnos { get; set; }
        public DbSet<Turno> turno { get; set; }
        public virtual DbSet<SpTurnosFiltro> get_turnos_filtro { get; set; }
        public virtual DbSet<SpCall> upd_anula_turno { get; set; }
        public virtual DbSet<SpCall> upd_modifica_cui { get; set; }
        public virtual DbSet<SpCall> upd_correo { get; set; }
        public virtual DbSet<SpCall> spGet_modulo_correo { get; set; }
        public CitasContext(DbContextOptions<CitasContext> options) : base(options)
        {

        }
    }
}
